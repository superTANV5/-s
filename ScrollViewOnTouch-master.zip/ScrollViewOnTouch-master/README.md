ScrollViewOnTouch
=================

仿百度助手头部搜索框缩放

![](https://github.com/18236887539/ScrollViewOnTouch/blob/master/1.gif)